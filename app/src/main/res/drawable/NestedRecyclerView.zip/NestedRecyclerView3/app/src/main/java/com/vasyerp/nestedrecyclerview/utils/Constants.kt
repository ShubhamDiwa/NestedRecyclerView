package com.vasyerp.nestedrecyclerview.utils

object Constants {
const val BASE_URL="https://api.themoviedb.org/"
const val Auth="Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIzMGFmMjQ5MzIwNGE0ZWJmZGU5YWJiMzM3NWRiYTU4MiIsInN1YiI6IjY0ZjJjZDk3MWYzMzE5MDBhZDQ3MGRjZSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.UUU2VDjGaSlnyGCGOjp6LFjuTW1a-uXBvyr_jMSEiW4"
}