package com.vasyerp.nestedrecyclerview.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}