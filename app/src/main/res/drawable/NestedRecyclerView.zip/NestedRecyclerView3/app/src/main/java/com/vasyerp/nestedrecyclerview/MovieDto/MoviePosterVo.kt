package com.vasyerp.nestedrecyclerview.MovieDto

data class MoviePosterVo(var imgPoster:String,
    var Title:String)
