package com.vasyerp.nestedrecyclerview.MovieDto

data class MovieDTO(var Title: String, val Pos: ArrayList<MoviePosterVo>)
